
$('.multiple-items').slick({
    infinite: true,
    slidesToShow: 3,
  slidesToScroll: 3
});

$('.single-item').slick();