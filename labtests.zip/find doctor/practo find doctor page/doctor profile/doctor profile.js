src="https://kit.fontawesome.com/fba4772d23.js"
crossorigin="anonymous"