  
        






        // <!-- SLIDER 1 J QUERY -->
          $("#slider_sec3").slick({
            infinite: false,
            slidesToShow: 6,
            slidesToScroll: 1,
            speed: 800,
            prevArrow:
              '<i class="fas fa-chevron-left    slid3_left-arrow" ></i>',
            nextArrow:
              '<i class="fas fa-chevron-right   slid3_right-arrow"></i>',
          });

          // <!-- SLIDER 2 J QUERY -->

          $("#slider_sec4").slick({
            infinite: false,
            slidesToShow: 6,
            slidesToScroll: 1,
            speed: 800,
            prevArrow:
              '<i class="fas fa-chevron-left    slid4_left-arrow" ></i>',
            nextArrow:
              '<i class="fas fa-chevron-right   slid4_right-arrow"></i>',
          });

          // <!-- SLIDER 3 J QUERY -->
         
            $("#slider_sec7").slick({
              infinite: false,
              slidesToShow: 3,
              slidesToScroll: 1,
              speed: 800,
              prevArrow:
                '<i class="fas fa-chevron-left    slid7_left-arrow" ></i>',
              nextArrow:
                '<i class="fas fa-chevron-right   slid7_right-arrow"></i>',
            });

            // <!-- SLIDER 4 J QUERY -->

           $('#sec11_slider').slick({
             dots:true,
             autoplay:true,
             autoplaySpeed:1200,
             arrows:false,
           });

           // <!-- SLIDER 5 J QUERY -->

          $(".sec5_slider").slick({
            infinite: false,
            slidesToShow: 3,
            slidesToScroll: 1,
            speed: 800,
            prevArrow:
              '<i class="fas fa-chevron-left    slid5_left-arrow" ></i>',
            nextArrow:
              '<i class="fas fa-chevron-right   slid5_right-arrow"></i>',
          });
